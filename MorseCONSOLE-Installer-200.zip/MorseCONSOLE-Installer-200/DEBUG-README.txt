MorseCONSOLE 0.154_debug - diagnostic build
Uses the same configuration and licence as 0.154; no master reset is needed.
1. Reproduce failed transmission with BK-IN ON. Test only on an appropriate load/frequency.
2. Reproduce missing spectrum without resetting the radio.
3. Close MorseCONSOLE to finish the session.
4. Send cat-debug.log (and .previous if present), tx-events.log, rf-diagnostics.log,
   rf-frames-debug.log, audio-diagnostics.log and all rf-frame-*.bin files.
Files are in %LOCALAPPDATA%\Programs\MorseCONSOLE when installed.
If spectrum subsequently works, restart the application and collect another set,
labelled WORKING. Keep the failing files in a separate folder before restarting.
Logs contain frequencies, transmitted text and station details.
No files are uploaded automatically.
