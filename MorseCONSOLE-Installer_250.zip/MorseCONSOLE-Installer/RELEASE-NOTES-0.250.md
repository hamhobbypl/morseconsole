## MorseCONSOLE 0.250 — changes since 0.236

### New SWR scanner

- Open **SWR Scan** from the top menu to plot SWR against frequency and find the lowest measured SWR.
- Measurements use short **5 W carrier pulses**, with frequency changes made only in receive.
- The default range covers the CW section of the current TX band, with a **5 kHz step**. The range and step can be adjusted within the same supported amateur band.
- The scanner follows the radio's TX VFO: the selected VFO without SPLIT, or the opposite VFO with SPLIT enabled.
- During scanning, the app temporarily selects the measurement VFO and disables SPLIT. Previous VFO selection, SPLIT, frequency, mode, power and other modified settings are restored after completion, STOP or an error, once RX is confirmed.
- The application's **AF GAIN** is muted during the scan and restored afterwards.
- **STOP**, the radio's HI-SWR alarm, an SWR reading above **3:1**, missing RF output or a CAT error stop the measurement.
- Results can be exported to **CSV**. Diagnostic details are saved in swr-scan.log.
- The scanner window uses the application's dark styling, rounded corners and custom title bar.

The antenna tuner must be OFF. Scanning transmits RF; select a clear range permitted by your licence. SWR and power values are approximate readings from the radio's meters, not a calibrated antenna analyser measurement.

### SPLIT and CLAR with CW via CAT

- **CW via CAT** now allows SPLIT and CLAR operation in AUTO, MANUAL and macro modes.
- Native CAT CW playback uses the radio's existing TX VFO and clarifier settings without applying an additional frequency correction.
- Audio-based CW transmission retains its existing restrictions.

### Clearer VFO controls and indicators

- **SPLIT** replaces the former LOCK button in both compact and full-screen layouts.
- The button enables or disables SPLIT on the FT-710 through CAT and shows the confirmed radio state.
- With SPLIT enabled, the large frequency readout temporarily shows the TX VFO during transmission, then returns to the RX VFO.
- Small rounded **RX** and **TX** badges identify each VFO's role. RX is green with white text; TX is red with white text.

### Updating

Install over the existing version. The installer preserves user configuration, registration and QSO data.
